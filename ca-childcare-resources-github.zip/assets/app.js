
const menu = document.querySelector('.mobile-toggle');
const links = document.querySelector('.nav-links');
if(menu && links){
  menu.addEventListener('click',()=>links.classList.toggle('open'));
}
const search = document.querySelector('#resourceSearch');
const chips = document.querySelectorAll('.chip[data-filter]');
const cards = document.querySelectorAll('.resource-card');
let active = 'all';
function filterCards(){
  const q = (search?.value || '').toLowerCase().trim();
  cards.forEach(card=>{
    const hay=(card.dataset.search || card.innerText).toLowerCase();
    const category=card.dataset.category || '';
    const matchText=!q || hay.includes(q);
    const matchCat=active==='all' || category===active;
    card.classList.toggle('hidden',!(matchText && matchCat));
  });
}
if(search) search.addEventListener('input',filterCards);
chips.forEach(chip=>chip.addEventListener('click',()=>{
  chips.forEach(c=>c.classList.remove('active'));
  chip.classList.add('active');
  active=chip.dataset.filter;
  filterCards();
}));
document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
